# Detection Script: Auto Disconnect
# ASD Blueprint for Secure Cloud - Intune Remediation Detection
# Registry: HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters
# Value: AutoDisconnect = 15 (DWORD) — disconnect idle sessions after 15 minutes
# Purpose: Automatically disconnects idle SMB sessions to reduce attack surface

$regPath  = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"
$regName  = "AutoDisconnect"
$expected = 15

try {
    $value = Get-ItemPropertyValue -Path $regPath -Name $regName -ErrorAction Stop
    if ($value -eq $expected) {
        Write-Host "COMPLIANT: $regName = $value"
        exit 0
    } else {
        Write-Host "NON-COMPLIANT: $regName = $value (expected $expected)"
        exit 1
    }
} catch {
    Write-Host "NON-COMPLIANT: $regName not found or inaccessible. $_"
    exit 1
}
