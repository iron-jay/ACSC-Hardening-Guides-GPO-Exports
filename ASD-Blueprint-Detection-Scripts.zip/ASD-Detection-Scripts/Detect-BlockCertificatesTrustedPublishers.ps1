# Detection Script: Block Certificates from Trusted Publishers (Current User Store Only)
# ASD Blueprint for Secure Cloud - Intune Remediation Detection
# Registry: HKLM\SOFTWARE\Policies\Microsoft\SystemCertificates\TrustedPublisher\Safer
# Value: AuthenticodeFlags = 3 (DWORD)
# Purpose: Prevents certificates installed only in the current user certificate store
#          from being treated as trusted publishers (machine-wide store required)

$regPath  = "HKLM:\SOFTWARE\Policies\Microsoft\SystemCertificates\TrustedPublisher\Safer"
$regName  = "AuthenticodeFlags"
$expected = 3

try {
    $value = Get-ItemPropertyValue -Path $regPath -Name $regName -ErrorAction Stop
    if ($value -eq $expected) {
        Write-Host "COMPLIANT: $regName = $value"
        exit 0
    } else {
        Write-Host "NON-COMPLIANT: $regName = $value (expected $expected)"
        exit 1
    }
} catch {
    Write-Host "NON-COMPLIANT: $regName not found or inaccessible. $_"
    exit 1
}
