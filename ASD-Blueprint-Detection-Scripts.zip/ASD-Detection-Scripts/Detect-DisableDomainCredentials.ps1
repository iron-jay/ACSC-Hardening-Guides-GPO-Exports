# Detection Script: Disable Domain Credentials
# ASD Blueprint for Secure Cloud - Intune Remediation Detection
# Registry: HKLM\SYSTEM\CurrentControlSet\Control\Lsa
# Value: DisableDomainCreds = 1 (DWORD)
# Purpose: Prevents Credential Manager from storing domain credentials,
#          reducing credential theft risk

$regPath  = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"
$regName  = "DisableDomainCreds"
$expected = 1

try {
    $value = Get-ItemPropertyValue -Path $regPath -Name $regName -ErrorAction Stop
    if ($value -eq $expected) {
        Write-Host "COMPLIANT: $regName = $value"
        exit 0
    } else {
        Write-Host "NON-COMPLIANT: $regName = $value (expected $expected)"
        exit 1
    }
} catch {
    Write-Host "NON-COMPLIANT: $regName not found or inaccessible. $_"
    exit 1
}
