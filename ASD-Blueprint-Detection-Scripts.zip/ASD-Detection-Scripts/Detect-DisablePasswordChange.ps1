# Detection Script: Disable Password Change
# ASD Blueprint for Secure Cloud - Intune Remediation Detection
# Registry: HKLM\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters
# Value: DisablePasswordChange = 1 (DWORD)
# Purpose: Prevents the domain member from automatically changing its machine account password,
#          aligning with LAPS or similar managed credential approaches

$regPath  = "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters"
$regName  = "DisablePasswordChange"
$expected = 1

try {
    $value = Get-ItemPropertyValue -Path $regPath -Name $regName -ErrorAction Stop
    if ($value -eq $expected) {
        Write-Host "COMPLIANT: $regName = $value"
        exit 0
    } else {
        Write-Host "NON-COMPLIANT: $regName = $value (expected $expected)"
        exit 1
    }
} catch {
    Write-Host "NON-COMPLIANT: $regName not found or inaccessible. $_"
    exit 1
}
