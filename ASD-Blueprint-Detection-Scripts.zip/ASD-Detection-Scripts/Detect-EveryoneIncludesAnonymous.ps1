# Detection Script: Everyone Includes Anonymous
# ASD Blueprint for Secure Cloud - Intune Remediation Detection
# Registry: HKLM\SYSTEM\CurrentControlSet\Control\Lsa
# Value: EveryoneIncludesAnonymous = 0 (DWORD)
# Purpose: Ensures the Everyone group does NOT include anonymous users,
#          preventing unauthenticated access via inherited Everyone permissions

$regPath  = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"
$regName  = "EveryoneIncludesAnonymous"
$expected = 0

try {
    $value = Get-ItemPropertyValue -Path $regPath -Name $regName -ErrorAction Stop
    if ($value -eq $expected) {
        Write-Host "COMPLIANT: $regName = $value"
        exit 0
    } else {
        Write-Host "NON-COMPLIANT: $regName = $value (expected $expected)"
        exit 1
    }
} catch {
    Write-Host "NON-COMPLIANT: $regName not found or inaccessible. $_"
    exit 1
}
