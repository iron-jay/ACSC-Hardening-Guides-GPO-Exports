# Detection Script: Force Key Protection
# ASD Blueprint for Secure Cloud - Intune Remediation Detection
# Registry: HKLM\SOFTWARE\Policies\Microsoft\Cryptography
# Value: ForceKeyProtection = 2 (DWORD)
# Purpose: Forces strong private key protection — user must enter a password
#          each time a private key is used by an application
# Values: 0 = No protection, 1 = Prompt once, 2 = Prompt every use

$regPath  = "HKLM:\SOFTWARE\Policies\Microsoft\Cryptography"
$regName  = "ForceKeyProtection"
$expected = 2

try {
    $value = Get-ItemPropertyValue -Path $regPath -Name $regName -ErrorAction Stop
    if ($value -eq $expected) {
        Write-Host "COMPLIANT: $regName = $value"
        exit 0
    } else {
        Write-Host "NON-COMPLIANT: $regName = $value (expected $expected)"
        exit 1
    }
} catch {
    Write-Host "NON-COMPLIANT: $regName not found or inaccessible. $_"
    exit 1
}
