# Detection Script: LDAP Client Integrity
# ASD Blueprint for Secure Cloud - Intune Remediation Detection
# Registry: HKLM\SYSTEM\CurrentControlSet\Services\ldap
# Value: LDAPClientIntegrity = 1 (DWORD)
# Purpose: Requires LDAP signing for communications with domain controllers,
#          preventing LDAP relay/man-in-the-middle attacks
# Values: 0 = None, 1 = Negotiate signing, 2 = Require signing

$regPath  = "HKLM:\SYSTEM\CurrentControlSet\Services\ldap"
$regName  = "LDAPClientIntegrity"
$expected = 1

try {
    $value = Get-ItemPropertyValue -Path $regPath -Name $regName -ErrorAction Stop
    if ($value -eq $expected) {
        Write-Host "COMPLIANT: $regName = $value"
        exit 0
    } else {
        Write-Host "NON-COMPLIANT: $regName = $value (expected $expected)"
        exit 1
    }
} catch {
    Write-Host "NON-COMPLIANT: $regName not found or inaccessible. $_"
    exit 1
}
