# Detection Script: Maximum Password Age
# ASD Blueprint for Secure Cloud - Intune Remediation Detection
# Registry: HKLM\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters
# Value: MaximumPasswordAge = 30 (DWORD) — machine account password max age in days
# Purpose: Limits the maximum age of machine account passwords to 30 days,
#          ensuring regular rotation of computer account credentials

$regPath  = "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters"
$regName  = "MaximumPasswordAge"
$expected = 30

try {
    $value = Get-ItemPropertyValue -Path $regPath -Name $regName -ErrorAction Stop
    if ($value -eq $expected) {
        Write-Host "COMPLIANT: $regName = $value"
        exit 0
    } else {
        Write-Host "NON-COMPLIANT: $regName = $value (expected $expected)"
        exit 1
    }
} catch {
    Write-Host "NON-COMPLIANT: $regName not found or inaccessible. $_"
    exit 1
}
