# Detection Script: OB Case Insensitive
# ASD Blueprint for Secure Cloud - Intune Remediation Detection
# Registry: HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Kernel
# Value: ObCaseInsensitive = 1 (DWORD)
# Purpose: Ensures the Windows object namespace is treated as case-insensitive,
#          which is the required default — aligns with hardening guidance to
#          confirm this value has not been tampered with

$regPath  = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Kernel"
$regName  = "ObCaseInsensitive"
$expected = 1

try {
    $value = Get-ItemPropertyValue -Path $regPath -Name $regName -ErrorAction Stop
    if ($value -eq $expected) {
        Write-Host "COMPLIANT: $regName = $value"
        exit 0
    } else {
        Write-Host "NON-COMPLIANT: $regName = $value (expected $expected)"
        exit 1
    }
} catch {
    Write-Host "NON-COMPLIANT: $regName not found or inaccessible. $_"
    exit 1
}
