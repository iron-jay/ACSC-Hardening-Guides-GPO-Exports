# Detection Script: Office Macro Hardening - Prevent Activation of OLE
# ASD Blueprint for Secure Cloud - Intune Remediation Detection
# Checks multiple registry keys that prevent OLE package activation across Office apps
# Purpose: Prevents embedded OLE objects from launching external executables via Office macros

$compliant = $true
$results   = @()

$settings = @(
    @{ Path = "HKLM:\SOFTWARE\Microsoft\Office\Word\Security";      Name = "PackagerPrompt";   Expected = 2 },
    @{ Path = "HKLM:\SOFTWARE\Microsoft\Office\Excel\Security";     Name = "PackagerPrompt";   Expected = 2 },
    @{ Path = "HKLM:\SOFTWARE\Microsoft\Office\PowerPoint\Security";Name = "PackagerPrompt";   Expected = 2 },
    @{ Path = "HKLM:\SOFTWARE\Microsoft\Office\Word\Security";      Name = "OLESecurityPromptUserOverride"; Expected = 0 },
    @{ Path = "HKLM:\SOFTWARE\Microsoft\Office\Excel\Security";     Name = "OLESecurityPromptUserOverride"; Expected = 0 },
    @{ Path = "HKLM:\SOFTWARE\Microsoft\Office\PowerPoint\Security";Name = "OLESecurityPromptUserOverride"; Expected = 0 }
)

foreach ($s in $settings) {
    try {
        $value = Get-ItemPropertyValue -Path $s.Path -Name $s.Name -ErrorAction Stop
        if ($value -ne $s.Expected) {
            $compliant = $false
            $results  += "NON-COMPLIANT: $($s.Path)\$($s.Name) = $value (expected $($s.Expected))"
        } else {
            $results  += "COMPLIANT: $($s.Path)\$($s.Name) = $value"
        }
    } catch {
        $compliant = $false
        $results  += "NON-COMPLIANT: $($s.Path)\$($s.Name) not found. $_"
    }
}

$results | ForEach-Object { Write-Host $_ }

if ($compliant) {
    Write-Host "OVERALL: COMPLIANT"
    exit 0
} else {
    Write-Host "OVERALL: NON-COMPLIANT"
    exit 1
}
