# Detection Script: Protection Mode
# ASD Blueprint for Secure Cloud - Intune Remediation Detection
# Registry: HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Kernel
# Value: ProtectionMode = 1 (DWORD)
# Purpose: Enables kernel object protection mode, which prevents user-mode
#          processes from naming objects in global namespaces that could
#          be used for privilege escalation attacks

$regPath  = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Kernel"
$regName  = "ProtectionMode"
$expected = 1

try {
    $value = Get-ItemPropertyValue -Path $regPath -Name $regName -ErrorAction Stop
    if ($value -eq $expected) {
        Write-Host "COMPLIANT: $regName = $value"
        exit 0
    } else {
        Write-Host "NON-COMPLIANT: $regName = $value (expected $expected)"
        exit 1
    }
} catch {
    Write-Host "NON-COMPLIANT: $regName not found or inaccessible. $_"
    exit 1
}
