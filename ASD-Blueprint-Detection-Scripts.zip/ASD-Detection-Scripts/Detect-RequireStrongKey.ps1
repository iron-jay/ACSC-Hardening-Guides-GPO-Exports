# Detection Script: Require Strong Key
# ASD Blueprint for Secure Cloud - Intune Remediation Detection
# Registry: HKLM\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters
# Value: RequireStrongKey = 1 (DWORD)
# Purpose: Requires a strong session key (128-bit) for Netlogon secure channel
#          data, ensuring stronger cryptographic protection of domain traffic

$regPath  = "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters"
$regName  = "RequireStrongKey"
$expected = 1

try {
    $value = Get-ItemPropertyValue -Path $regPath -Name $regName -ErrorAction Stop
    if ($value -eq $expected) {
        Write-Host "COMPLIANT: $regName = $value"
        exit 0
    } else {
        Write-Host "NON-COMPLIANT: $regName = $value (expected $expected)"
        exit 1
    }
} catch {
    Write-Host "NON-COMPLIANT: $regName not found or inaccessible. $_"
    exit 1
}
