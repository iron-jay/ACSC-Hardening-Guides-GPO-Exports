# Detection Script: SCENo Apply Legacy Audit Policy
# ASD Blueprint for Secure Cloud - Intune Remediation Detection
# Registry: HKLM\SYSTEM\CurrentControlSet\Control\Lsa
# Value: SCENoApplyLegacyAuditPolicy = 1 (DWORD)
# Purpose: Ensures advanced audit policy settings (configured via auditpol.exe or
#          Group Policy > Advanced Audit Policy Configuration) take precedence over
#          the legacy audit policy in Security Settings, preventing conflicts

$regPath  = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"
$regName  = "SCENoApplyLegacyAuditPolicy"
$expected = 1

try {
    $value = Get-ItemPropertyValue -Path $regPath -Name $regName -ErrorAction Stop
    if ($value -eq $expected) {
        Write-Host "COMPLIANT: $regName = $value"
        exit 0
    } else {
        Write-Host "NON-COMPLIANT: $regName = $value (expected $expected)"
        exit 1
    }
} catch {
    Write-Host "NON-COMPLIANT: $regName not found or inaccessible. $_"
    exit 1
}
