# Detection Script: Seal Secure Channel
# ASD Blueprint for Secure Cloud - Intune Remediation Detection
# Registry: HKLM\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters
# Value: SealSecureChannel = 1 (DWORD)
# Purpose: Requires all Netlogon secure channel data to be encrypted (sealed),
#          ensuring confidentiality of domain authentication traffic

$regPath  = "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters"
$regName  = "SealSecureChannel"
$expected = 1

try {
    $value = Get-ItemPropertyValue -Path $regPath -Name $regName -ErrorAction Stop
    if ($value -eq $expected) {
        Write-Host "COMPLIANT: $regName = $value"
        exit 0
    } else {
        Write-Host "NON-COMPLIANT: $regName = $value (expected $expected)"
        exit 1
    }
} catch {
    Write-Host "NON-COMPLIANT: $regName not found or inaccessible. $_"
    exit 1
}
