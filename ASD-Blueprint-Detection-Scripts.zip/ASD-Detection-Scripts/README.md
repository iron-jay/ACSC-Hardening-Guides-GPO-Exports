# ASD Blueprint Detection Scripts
## Intune Remediation Detection — ASD Blueprint for Secure Cloud

These 19 PowerShell detection scripts correspond to each remediation script listed at:
https://blueprint.asd.gov.au/configuration/intune/devices/scripts/

Each script exits with code **0** (compliant) or **1** (non-compliant), suitable for use
as the **Detection** script in an Intune Remediation policy paired with its counterpart
remediation script from the Microsoft ACSC GitHub repository.

---

## Scripts & Registry Keys Checked

| Detection Script | Registry Path | Value Name | Expected |
|---|---|---|---|
| Detect-AllowNullSessionFallback.ps1 | HKLM\SYSTEM\CCS\Services\LanmanWorkstation\Parameters | AllowNullSessionFallback | 0 |
| Detect-AutoDisconnect.ps1 | HKLM\SYSTEM\CCS\Services\LanmanServer\Parameters | AutoDisconnect | 15 |
| Detect-BlockCertificatesTrustedPublishers.ps1 | HKLM\SOFTWARE\Policies\Microsoft\SystemCertificates\TrustedPublisher\Safer | AuthenticodeFlags | 3 |
| Detect-DisableDomainCredentials.ps1 | HKLM\SYSTEM\CCS\Control\Lsa | DisableDomainCreds | 1 |
| Detect-DisablePasswordChange.ps1 | HKLM\SYSTEM\CCS\Services\Netlogon\Parameters | DisablePasswordChange | 1 |
| Detect-EveryoneIncludesAnonymous.ps1 | HKLM\SYSTEM\CCS\Control\Lsa | EveryoneIncludesAnonymous | 0 |
| Detect-FIPSAlgorithmPolicy.ps1 | HKLM\SYSTEM\CCS\Control\Lsa\FipsAlgorithmPolicy | Enabled | 1 |
| Detect-ForceKeyProtection.ps1 | HKLM\SOFTWARE\Policies\Microsoft\Cryptography | ForceKeyProtection | 2 |
| Detect-LDAPClientIntegrity.ps1 | HKLM\SYSTEM\CCS\Services\ldap | LDAPClientIntegrity | 1 |
| Detect-MaximumPasswordAge.ps1 | HKLM\SYSTEM\CCS\Services\Netlogon\Parameters | MaximumPasswordAge | 30 |
| Detect-OBCaseInsensitive.ps1 | HKLM\SYSTEM\CCS\Control\Session Manager\Kernel | ObCaseInsensitive | 1 |
| Detect-OfficeMacroHardening-PreventActivationOfOLE.ps1 | HKLM\SOFTWARE\Microsoft\Office\{Word,Excel,PowerPoint}\Security | PackagerPrompt + OLESecurityPromptUserOverride | 2 / 0 |
| Detect-ProtectionMode.ps1 | HKLM\SYSTEM\CCS\Control\Session Manager\Kernel | ProtectionMode | 1 |
| Detect-RequireSignOrSeal.ps1 | HKLM\SYSTEM\CCS\Services\Netlogon\Parameters | RequireSignOrSeal | 1 |
| Detect-RequireStrongKey.ps1 | HKLM\SYSTEM\CCS\Services\Netlogon\Parameters | RequireStrongKey | 1 |
| Detect-SCENoApplyLegacyAuditPolicy.ps1 | HKLM\SYSTEM\CCS\Control\Lsa | SCENoApplyLegacyAuditPolicy | 1 |
| Detect-SealSecureChannel.ps1 | HKLM\SYSTEM\CCS\Services\Netlogon\Parameters | SealSecureChannel | 1 |
| Detect-SignSecureChannel.ps1 | HKLM\SYSTEM\CCS\Services\Netlogon\Parameters | SignSecureChannel | 1 |
| Detect-UserApplicationHardening-RemoveFeatures.ps1 | Windows Optional Features | PS v2, .NET 3.5, IE11 | Disabled |

*CCS = CurrentControlSet*

---

## Intune Remediation Setup

For each pair:
1. In Intune → **Devices > Remediations > Create**
2. **Detection script**: upload the matching `Detect-*.ps1` from this folder
3. **Remediation script**: upload the corresponding `.ps1` from https://github.com/microsoft/Intune-ACSC-Windows-Hardening-Guidelines/tree/main/scripts
4. Run as **SYSTEM** (not logged-on user)
5. Run in **64-bit PowerShell** for the RemoveFeatures script; 32-bit is fine for the registry scripts

## Notes

- The `DisablePasswordChange` script should only be used if you have a machine password management solution (e.g. LAPS) in place — setting this without LAPS can prevent domain authentication.
- The `FIPSAlgorithmPolicy` setting may break some legacy applications; test in a staging environment first.
- The `UserApplicationHardening-RemoveFeatures` detection uses `Get-WindowsOptionalFeature` which requires elevation (runs as SYSTEM in Intune — this is fine).

## References

- [ASD Blueprint — Intune Scripts](https://blueprint.asd.gov.au/configuration/intune/devices/scripts/)
- [Microsoft ACSC Windows Hardening Guidelines (GitHub)](https://github.com/microsoft/Intune-ACSC-Windows-Hardening-Guidelines)
- [Intune Remediations Documentation](https://docs.microsoft.com/mem/intune/fundamentals/remediations)
